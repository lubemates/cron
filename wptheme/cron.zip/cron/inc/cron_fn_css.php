<?php

function cron_fn_inline_styles() {
	
	global $cron_fn_option; 
	
	
	
	wp_enqueue_style('cron_fn_inline', get_template_directory_uri().'/framework/css/inline.css', array(), '1.0', 'all');
	/************************** START styles **************************/
	$cron_fn_custom_css = "
		.cron_fn_header ul.vert_nav > li > a{
			font-family:'{$cron_fn_option['nav_font']['font-family']}', Rubik, Arial, Helvetica, sans-serif; 
			font-size:{$cron_fn_option['nav_font']['font-size']};  
			font-weight:{$cron_fn_option['nav_font']['font-weight']};  
		}
		.cron_fn_header .header_button a{
			font-family:'{$cron_fn_option['nav_font']['font-family']}', Rubik, Arial, Helvetica, sans-serif;
			font-weight:{$cron_fn_option['nav_font']['font-weight']};
		}
		.cron_fn_header ul.vert_nav > li > ul a{
			font-family:'{$cron_fn_option['nav_font']['font-family']}', Rubik, Arial, Helvetica, sans-serif;
		}
		
		.cron_fn_mobilemenu_wrap .vert_menu_list a{
			font-family:'{$cron_fn_option['nav_mob_font']['font-family']}', Montserrat, Arial, Helvetica, sans-serif; 
			font-size:{$cron_fn_option['nav_mob_font']['font-size']};  
			font-weight:{$cron_fn_option['nav_mob_font']['font-weight']};  
		}
		
		
		body{
			font-family:'{$cron_fn_option['body_font']['font-family']}', Open Sans, Arial, Helvetica, sans-serif; 
			font-size:{$cron_fn_option['body_font']['font-size']};  
			font-weight:{$cron_fn_option['body_font']['font-weight']};  
		}
		
		.uneditable-input, input[type=number], input[type=email], input[type=url], input[type=search], input[type=tel], input[type=color], input[type=text], input[type=password], input[type=datetime], input[type=datetime-local], input[type=date], input[type=month], input[type=time], input[type=week], input, button, select, textarea{
			font-family: '{$cron_fn_option['input_font']['font-family']}', Open Sans, Arial, Helvetica, sans-serif; 
			font-size:{$cron_fn_option['input_font']['font-size']}; 
			font-weight:{$cron_fn_option['input_font']['font-weight']};
		}
		
		
		h1,h2,h3,h4,h5,h6{
			font-family: '{$cron_fn_option['heading_font']['font-family']}', Rubik, Arial, Helvetica, sans-serif;
			font-weight:{$cron_fn_option['heading_font']['font-weight']};
		}
		
		.fn_cs_main_slider_with_content .control_panel .swiper_pagination > span,
		.fn_cs_services_classic span.more_details a,
		.fn_cs_button a,
		.fn_cs_principles .right_part .number_holder,
		.fn_cs_project_sticky_modern .left_part a,
		.fn_cs_project_sticky_modern .right_part .title_holder p a,
		.fn_cs_title_modern .title_holder span,
		.fn_cs_service_query_modern .t_inner a,
		.fn_cs_info_list_modern .list ul li .item .bottom_holder a,
		.fn_cs_project_carousel ul.slides .item .title_holder p a,
		.fn_cs_quadruple_blog .inner .left_part .title_holder p,
		.fn_cs_quadruple_blog .inner .left_part .title_holder a.icon,
		.fn_cs_quadruple_blog .inner .right_part .other_item a.icon,
		.fn_cs_quadruple_blog .inner .right_part .see_all a,
		.fn_cs_testimonial_carousel .owl-item .title_holder p,
		.wid-title span,
		.cron_fn_widget_estimate .bfwe_inner a,
		.cron_fn_custom_lang_switcher span.click,
		.cron_fn_header .header_button a,
		.cron_fn_header .header_inner .header_top > div a,
		.cron_fn_header .header_inner .header_top > div,
		.cons_w_wrapper .fn_cs_hero_header_modern .video .text{
			font-family: '{$cron_fn_option['heading_font']['font-family']}', Rubik, Arial, Helvetica, sans-serif;
		}
		
		blockquote{
			font-family: '{$cron_fn_option['blockquote_font']['font-family']}', Lora, Arial, Helvetica, sans-serif; 
			font-size:{$cron_fn_option['blockquote_font']['font-size']}; 
			font-weight:{$cron_fn_option['blockquote_font']['font-weight']};
		}
		
		.fn_cs_counter_with_rating .rating_holder h3.rating_number,
		.cron_fn_widget_brochure .text,
		ul.cron_fn_archive_list .read_more a,
		.cron_fn_portfolio_category_filter > a,
		.cron_fn_portfolio_category_filter ul a,
		ul.ajax_pagination a,
		ul.cron_fn_portfolio_list .title_holder p,
		a.cron_fn_totop .text,
		.service_single .other_services .read_more a{
			font-family: '{$cron_fn_option['extra_font']['font-family']}', Montserrat, Arial, Helvetica, sans-serif;
		}
	";
	
	// HEADING COLOR
	$heading_color = '#14141c';
	if(isset($cron_fn_option['heading_color'])){
		$heading_color = $cron_fn_option['heading_color'];
	}
	if(isset($_GET['heading_color'])){$heading_color = $_GET['heading_color'];}
	$cron_fn_custom_css .= "
		h1 > a,
		h2 > a,
		h3 > a,
		h4 > a,
		h5 > a,
		h6 > a,
		.wid-title span,
		.cron_fn_widget_estimate .bfwe_inner a,
		.cron_fn_header ul.vert_nav > li > a,
		.cron_fn_footer .widget_tag_cloud .tagcloud a,
		.cron_fn_pagetitle h3,
		.blog_single_title .title_holder h3,
		.cron_fn_comment h3.comment-title,
		.cron_fn_comment span.author,
		.cron_fn_comment span.author a,
		ul.cron_fn_postlist .sticky_icon,
		ul.cron_fn_archive_list h3 a,
		.cron_fn_share_icons label,
		.cron_fn_share_icons ul li a,
		.cron_fn_portfolio_details .title_holder h3,
		ul.cron_fn_service_list .title_holder h3 a{color: {$heading_color};}
		.cron_fn_header ul.vert_nav > li.menu-item-has-children > a:after{border-top-color: {$heading_color};}
	";
	
	
	// PRIMARY COLOR
	$primary_color = '#ff4b36';
	if(isset($cron_fn_option['primary_color'])){
		$primary_color = $cron_fn_option['primary_color'];
	}
	$cron_fn_custom_css .= "
		input[type=button],
		input[type=submit],
		.wid-title span:after,
		.widget_tag_cloud a,
		.cron_fn_widget_estimate .bfwe_inner,
		.cron_fn_border .left_wing:after,
		.cron_fn_border .right_wing:after,
		.cron_fn_header .header_button a:hover,
		.cron_fn_tags a,
		.cron_fn_pagelinks a,
		.cron_fn_pagelinks span.number,
		.cron_fn_pagelinks span.number:hover,
		.cron_fn_postlist .time span:after,
		ul.cron_fn_postlist .read_holder a:hover,
		ul.cron_fn_archive_list .read_more a,
		.cron_fn_portfolio_category_filter > a,
		ul.ajax_pagination a,
		ul.cron_fn_portfolio_list .item:after,
		ul.cron_fn_portfolio_list .img_holder a:after,
		ul.cron_fn_portfolio_list .img_holder a:before,
		.cron_fn_portfolio_single_list .plus:after,
		.cron_fn_portfolio_single_list .plus:before,
		.cron_fn_portfolio_justified .j_list .plus:after,
		.cron_fn_portfolio_justified .j_list .plus:before,
		.cron_fn_prevnext[data-switch=prev] .prev a,
		.cron_fn_prevnext[data-switch=next] .next a,
		.cron_fn_prevnext[data-switch=yes] a,
		.cron_fn_pagination li span,
		.cron_fn_pagination li a:hover,
		a.cron_fn_totop .top,
		ul.cron_fn_service_list .item:hover .title_holder .read_more a,
		ul.cron_fn_service_list_default .img_holder .img_abs,
		ul.cron_fn_service_list_default .read_more a,
		.service_single .other_services .read_more a,
		.cron_fn_quick_contact input[type=button],
		ul.cron_fn_archive_list.blog_archive p.read_holder a:hover,
		.service_list_as_function li a:after{background-color: {$primary_color};}
		
		h1 > a:hover,
		h2 > a:hover,
		h3 > a:hover,
		h4 > a:hover,
		h5 > a:hover,
		h6 > a:hover,
		ul.cron_fn_archive_list.blog_archive p.t_header a,
		.cron_fn_header .header_button a,
		.cron_fn_wrapper_all[data-nav-skin=transdark] .cron_fn_header .header_button a:hover,
		.cron_fn_footer .subscribe_in .s_left svg,
		.cron_fn_blog_single .fn-format-link a:hover,
		.blog_single_title p.t_header a,
		body.single-post span.category a:hover,
		.cron_fn_comment span.author a:hover,
		.cron_fn_comment a.comment-edit-link,
		.cron_fn_comment div.comment-text p > a,
		.cron_fn_comment h3.comment-reply-title a,
		.cron_fn_comment .logged-in-as,
		.cron_fn_comment .logged-in-as a:first-child,
		.cron_fn_comment .logged-in-as a:last-child,
		.cron_fn_searchpagelist_item a.read_more,
		.cron_fn_error_page .error_box h1,
		ul.cron_fn_postlist .info_holder p a,
		ul.cron_fn_archive_list h3 a:hover,
		.cron_fn_breadcrumbs a:hover,
		ul.cron_fn_portfolio_list .item:hover .title_holder p a,
		.cron_fn_share_icons ul li a:hover,
		.cron_fn_portfolio_details .info_list p,
		.cron_fn_portfolio_details .info_list span a:hover,
		.cron_fn_portfolio_details .video_holder .play_text,
		.cron_fn_portfolio_justified .cron_fn_share_icons ul li a:hover,
		.cron_fn_portfolio_justified .video_holder .play_text span,
		.cron_fn_portfolio_justified .helpful_part p,
		.cron_fn_helpful_bar .helpful_list li a:hover,
		.cron_fn_helpful_bar .helpful_list li.clicked a,
		.cron_fn_helpful_bar_open .toll_free h3,
		.cron_fn_helpful_bar_open .working_hours li .hours,
		.cron_fn_mobilemenu_wrap .helpful_list li.clicked a,
		.cron_fn_mobilemenu_wrap .helpful_list a:hover,
		.cron_fn_mobilemenu_wrap .working_hours li .hours,
		.cron_fn_portfolio_justified .helpful_part span a:hover,
		.cron_fn_mobilemenu_wrap .toll_free h3,
		ul.cron_fn_service_list .title_holder h3 a:hover{color:{$primary_color};}
		
		
		
		
		
		.cron_fn_widget_estimate .helper5,
		.cron_fn_border .right_wing:before,
		ul.cron_fn_service_list .item:hover span.roof:after,
		ul.cron_fn_service_list .item:hover .title_holder .read_more:after,
		.cron_fn_widget_estimate .helper1{border-left-color:{$primary_color};}
		
		.cron_fn_widget_estimate .helper6,
		.cron_fn_border .left_wing:before,
		ul.cron_fn_service_list_default .read_more a:after,
		ul.cron_fn_service_list .item:hover span.roof:before,
		.cron_fn_widget_estimate .helper2{border-right-color:{$primary_color};}
		ul.cron_fn_postlist .info_holder p a,
		ul.cron_fn_archive_list.blog_archive p.t_header a,
		.blog_single_title p.t_header a{border-bottom-color:{$primary_color};}
		.cron_fn_postlist .time span:before{border-top-color:{$primary_color};}
		
		ul.cron_fn_service_list .item:hover .title_holder,
		.cron_fn_wrapper_all[data-nav-skin=transdark] .cron_fn_header .header_button a:hover,
		.cron_fn_header .header_button a{border-color:{$primary_color};}
		
		.cron_fn_footer .widget_oih_opt_in_widget button{background-color: {$primary_color} !important;}
		
		
		
	";
	
	// SECONDARY COLOR
	$secondary_color = '#14141c';
	if(isset($cron_fn_option['secondary_color'])){
		$secondary_color = $cron_fn_option['secondary_color'];
	}
	$cron_fn_custom_css .= "
		input[type=button]:hover,
		input[type=submit]:hover,
		.cron_fn_header .header_inner .header_top:after,
		.service_list_as_function,
		ul.cron_fn_archive_list .read_more a:hover,
		.cron_fn_prevnext[data-switch=prev] .prev a:hover,
		.cron_fn_prevnext[data-switch=yes] a:hover,
		.cron_fn_prevnext[data-switch=next] .next a:hover,
		.service_single .other_services .read_more a:hover,
		ul.cron_fn_service_list_default .read_more a:hover,
		ul.ajax_pagination a:not(.inactive):hover,
		.cron_fn_quick_contact input[type=button]:hover,
		.cron_fn_tags a:hover{background-color: {$secondary_color};}
		
		ul.cron_fn_service_list_default .read_more a:hover:after{
			border-right-color: {$secondary_color};
		}
		
		.cron_fn_footer .widget_oih_opt_in_widget button:hover{background-color: {$secondary_color} !important;}
	";
	
	// FOOTER WIDGET COLOR
	$footer_bottom_color = '#0b0f17';
	if(isset($cron_fn_option['footer_bottom_color'])){
		$footer_bottom_color = $cron_fn_option['footer_bottom_color'];
	}
	$cron_fn_custom_css .= "
		.cron_fn_footer .footer_bottom_in,
		.cron_fn_footer .footer_bottom{background-color: {$footer_bottom_color};}
	";
	/************************** font styles **************************/
	$cron_fn_custom_css .= "";
		
		
		
	wp_add_inline_style( 'cron_fn_inline', $cron_fn_custom_css );

			
}

?>