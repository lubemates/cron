<?php
function cron_fn_pagination($pages = '', $range = 1, $home = 0)
{  
	$currentPage = '';
	$showitems = ($range * 1) + 1;
	global $cron_fn_paged;
    
	if(get_query_var('paged')) {
		 $cron_fn_paged = get_query_var('paged');
	} elseif(get_query_var('page')) {
		 $cron_fn_paged = get_query_var('page');
	} else {
		 $cron_fn_paged = 1;
	}

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }
	 

     if(1 != $pages)
     {
		 echo '<div class="cron_fn_pagination"><ul>';
		 if($cron_fn_paged > 1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link(1)."' title='".esc_attr__('first','cron')."'>&larr; </a></li>";
         for ($i=1; $i <= $pages; $i++)
         {
			 if (1 != $pages &&( !($i >= $cron_fn_paged+$range+1 || $i <= $cron_fn_paged-$range-1) || $pages <= $showitems ))
             {
				if($home == 1){
					if($cron_fn_paged == $i){
						echo "<li><span class='current'>".esc_html($i)."</span></li>";
					}else{
						echo "<li><a href='".esc_url(add_query_arg( 'page', $i))."' class='inactive' >".esc_html($i)."</a></li>";
					}
					
				}else{
					if($cron_fn_paged == $i){
						echo "<li class='active'><span class='current'>".esc_html($i)."</span></li>";
					}else{
						echo "<li><a href='".esc_url( get_pagenum_link($i))."' class='inactive' >".esc_html($i)."</a></li>";
					}
				}
				if($cron_fn_paged == $i){
					$currentPage = $i;
				}
			 }
         }
		 if ($cron_fn_paged < $pages && $showitems < $pages) echo "<li><a href='".esc_url( get_pagenum_link($pages))."' title='".esc_attr__('last','cron')."'>&rarr;</a></li>";
		 echo '<li class="view"><p>'.sprintf('%s %s %s %s',esc_html__('Viewing page', 'cron'), $currentPage, esc_html__('of', 'cron'), $pages).'</p></li>';
         echo "</ul></div>\n";
     }
}



?>
