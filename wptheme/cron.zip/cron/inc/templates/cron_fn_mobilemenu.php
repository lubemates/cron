<?php 
	global $cron_fn_option, $post;
	$mobile_nav 			= array('theme_location'  => 'mobile_menu','menu_class' => 'vert_menu_list nav_ver','menu_id' => 'vert_menu_list');
	$mobileLogo 			= get_template_directory_uri().'/framework/img/mobile-logo.png';

	$logoMobile 			= $logoMobileURL = '';
	if(isset($cron_fn_option['mobile_logo'])){
		$logoMobile 		= $cron_fn_option['mobile_logo'];
	}
	if(isset($cron_fn_option['mobile_logo']['url'])){
		$logoMobileURL 	= $cron_fn_option['mobile_logo']['url'];
	}
	if(isset($logoMobile) && isset($logoMobileURL)){
		if($logoMobileURL !== ''){
			$mobileLogo = $logoMobileURL;
		}
	}
	// mobile navigation open by default
	$mobile_nav_open_default = 'disable';
	if(isset($cron_fn_option['mobile_nav_open_default'])){
		$mobile_nav_open_default = $cron_fn_option['mobile_nav_open_default'];
	}
	$isActive 			= '';
	$displayNone 		= '';
	if($mobile_nav_open_default === 'enable'){
		$isActive 		= 'is-active';
		$displayNone 	= 'style=display:block;';
	}
?>
<!-- INFO BAR OPENER -->
<div class="info_bar">
	<div class="info_bar_content">
		<div class="helpful_list">
			<ul>
				<?php if($cron_fn_option['helpful_address'] != 'disable'){ ?>
				<li data-help="home">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/home.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>

				<?php if($cron_fn_option['helpful_contact'] == 'enable'){ ?>
				<li data-help="message">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/message.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>

				<?php if($cron_fn_option['helpful_tollfree'] != 'disable'){ ?>
				<li data-help="phone">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/phone.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>

				<?php if($cron_fn_option['helpful_working_hours'] != 'disable'){ ?>
				<li data-help="clock">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/clock.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>
			</ul>
		</div>
		<div class="social_list">
			<ul>
				<?php if(isset($cron_fn_option['facebook_helpful']) == 1 && $cron_fn_option['facebook_helpful'] != '') { ?>
				<li><a class="facebook" href="<?php echo esc_url($cron_fn_option['facebook_helpful']); ?>" target="_blank"><i class="xcon-facebook"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['twitter_helpful']) == 1 && $cron_fn_option['twitter_helpful'] != '') { ?>
				<li><a class="twitter" href="<?php echo esc_url($cron_fn_option['twitter_helpful']); ?>" target="_blank"><i class="xcon-twitter"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['instagram_helpful']) == 1 && $cron_fn_option['instagram_helpful'] != '') { ?>
				<li><a class="instagram" href="<?php echo esc_url($cron_fn_option['instagram_helpful']); ?>" target="_blank"><i class="xcon-instagram"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['pinterest_helpful']) == 1 && $cron_fn_option['pinterest_helpful'] != '') { ?>
				<li><a class="pinterest" href="<?php echo esc_url($cron_fn_option['pinterest_helpful']); ?>" target="_blank"><i class="xcon-pinterest"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['linkedin_helpful']) == 1 && $cron_fn_option['linkedin_helpful'] != '') { ?>
				<li><a class="linkedin" href="<?php echo esc_url($cron_fn_option['linkedin_helpful']); ?>" target="_blank"><i class="xcon-linkedin"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['behance_helpful']) == 1 && $cron_fn_option['behance_helpful'] != '') { ?>
				<li><a class="behance" href="<?php echo esc_url($cron_fn_option['behance_helpful']); ?>" target="_blank"><i class="xcon-behance"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['vimeo_helpful']) == 1 && $cron_fn_option['vimeo_helpful'] != '') { ?>
				<li><a class="vimeo" href="<?php echo esc_url($cron_fn_option['vimeo_helpful']); ?>" target="_blank"><i class="xcon-vimeo"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['youtube_helpful']) == 1 && $cron_fn_option['youtube_helpful'] != '') { ?>
				<li><a class="youtube" href="<?php echo esc_url($cron_fn_option['youtube_helpful']); ?>" target="_blank"><i class="xcon-youtube"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['google_helpful']) == 1 && $cron_fn_option['google_helpful'] != '') { ?>
				<li><a class="google" href="<?php echo esc_url($cron_fn_option['google_helpful']); ?>" target="_blank"><i class="xcon-gplus"></i></a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
	<div class="info_bar_bg"></div>
</div>
<!-- /INFO BAR OPENER -->
<!-- LOGO & HAMBURGER -->
<div class="logo_hamb">
	<div class="in">
		<div class="menu_logo">
			<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url($mobileLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" /></a>
		</div>
		<div class="hamburger hamburger--collapse-r <?php echo esc_attr($isActive);?>">
			<div class="hamburger-box">
				<div class="hamburger-inner"></div>
			</div>
		</div>
	</div>
</div>
<!-- /LOGO & HAMBURGER -->

<!-- MOBILE DROPDOWN MENU -->
<div class="mobilemenu" <?php echo esc_attr($displayNone);?>>
	<?php if(has_nav_menu('mobile_menu')){ wp_nav_menu( $mobile_nav );} else{echo '<ul class="nav_ver vert_menu_list"><li><a href="">'.esc_html__('No menu assigned', 'cron').'</a></li></ul>';}?>
</div>
<!-- /MOBILE DROPDOWN MENU -->

<!-- INFO BAR DROPDOWN -->
<div class="info_bar_dropdown">
	<div class="fn_list home">
		<?php 
			// renew
			$ALImg = $ALImgURL = $ALImgCallBack = $ALImgDefaultURL = '';
			if(isset($cron_fn_option['helpful_address_list_img'])){
				$ALImg 					= $cron_fn_option['helpful_address_list_img'];
			}
			if(isset($cron_fn_option['helpful_address_list_img']['url'])){
				$ALImgURL 				= $cron_fn_option['helpful_address_list_img']['url'];
			}
			if(isset($ALImg) && isset($ALImgURL)){
				if($ALImgURL !== ''){
					$ALImgDefaultURL 	= $ALImgURL;
					$ALImgCallBack		= '<div class="al_img"><div class="abs_img" data-fn-bg-img="'.$ALImgDefaultURL.'"></div><img src="'.get_template_directory_uri().'/framework/img/thumb/thumb-320-200.jpg'.'" alt="'.esc_attr__("thumb", "cron").'" /></div>';
				}
			}
			if(isset($cron_fn_option['helpful_address_list_title'])){
				$titleA 				= $cron_fn_option['helpful_address_list_title'];
			}else{
				$titleA 				= esc_html__('Head Office in New-York', 'cron');
			}
			if(isset($cron_fn_option['helpful_address_list_content'])){
				$descA 					= $cron_fn_option['helpful_address_list_content'];
			}else{
				$descA 					= esc_html__('775 New York Ave, Brooklyn, NY 11203', 'cron');
			}
			$listAddress 				= '<div class="address_list">';
			$listAddress 				.= '<div class="item">'.$ALImgCallBack.'<div class="al_title"><h3>'.$titleA.'</h3><p>'.$descA.'</p></div></div>';
			$listAddress 				.= '</div>';
			echo wp_kses_post($listAddress);
		?>
	</div>
	<div class="fn_list message">
		<?php get_template_part('framework/modal/quick-contact');?>
	</div>
	<div class="fn_list phone">
		<?php 
			$tollfree_img = get_template_directory_uri().'/framework/img/call.png';
			$tollfree_img_config = $tollfree_img_configURL = '';
			if(isset($cron_fn_option['helpful_tollfree_img'])){
				$tollfree_img_config 	= $cron_fn_option['helpful_tollfree_img'];
			}
			if(isset($cron_fn_option['helpful_tollfree_img']['url'])){
				$tollfree_img_configURL = $cron_fn_option['helpful_tollfree_img']['url'];
			}
			if(isset($tollfree_img_config) && isset($tollfree_img_configURL)){
				if($tollfree_img_configURL !== ''){
					$tollfree_img = $tollfree_img_configURL;
				}
			}
		?>
		<div class="toll_free">
			<div class="img_holder">
				<img src="<?php echo esc_url($tollfree_img); ?>" alt="<?php echo esc_attr__('img', 'cron');?>" />
			</div>
			<div class="title_holder">
				<h3>
					<?php 
						if(isset($cron_fn_option['helpful_tollfree_title'])){ 
							echo wp_kses_post($cron_fn_option['helpful_tollfree_title']);
						}else{ 
							esc_html_e('Toll Free', 'cron');
						} 
					?>
				</h3>
				<h5>
					<?php 
						if(isset($cron_fn_option['helpful_tollfree_subtitle'])){ 
							echo wp_kses_post($cron_fn_option['helpful_tollfree_subtitle']);
						}else{ 
							echo '1-800-987-6543';
						} 
					?>
				</h5>
			</div>
		</div>
	</div>
	<div class="fn_list clock">
		<div class="working_hours">
			<div class="title_holder">
				<h3>
					<?php 
						if(isset($cron_fn_option['helpful_working_hours_title'])){ 
							echo wp_kses_post($cron_fn_option['helpful_working_hours_title']);
						}else{ 
							esc_html_e('Working Hours', 'cron');
						} 
					?>
				</h3>
				<p>
					<?php 
						if(isset($cron_fn_option['helpful_working_hours_subtitle'])){ 
							echo wp_kses_post($cron_fn_option['helpful_working_hours_subtitle']);
						}else{ 
							esc_html_e('We are happy to meet you during our working hours. Please make an appointment.', 'cron');
						} 
					?>
				</p>
			</div>
			<div class="days_holder">
				<ul>
					<?php 
						if(isset($cron_fn_option['helpful_working_hours_list']) && !empty($cron_fn_option['helpful_working_hours_list'])){
							$WHArray 	= $cron_fn_option['helpful_working_hours_list'];
							$WHItem 	= '';
							foreach($WHArray as $WHChild){
								$titleA 	= $WHChild['title'];
								$descA 		= $WHChild['description'];
								$WHItem .= '<li><span class="day">'.$titleA.'</span><span class="hours">'.$descA.'</span></li>';
							}
							echo wp_kses_post($WHItem);
						}
					?>
				</ul>
			</div>
		</div>
	</div>
</div>
<!-- /INFO BAR DROPDOWN -->