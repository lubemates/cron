<?php 
	global $cron_fn_option, $post;
	$ratingNumber 		= 9.7;
	$ratingText 		= esc_html__('Customer Rating', 'cron');
	if(isset($cron_fn_option)){
		$ratingNumber 	= $cron_fn_option['helpful_rating_number'];
		$ratingText 	= $cron_fn_option['helpful_rating_text'];
	}
	
?>
   
<div class="cron_fn_helpful_bar">
	<div class="cron_fn_helpful_bar_content">
		<div class="rating_holder">
			<div class="r_footer"></div>
			<img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/stars.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" />
			<h3 class="rating_number"><?php echo esc_html($ratingNumber);?></h3>
			<h3 class="rating_text"><?php echo esc_html($ratingText);?></h3>
		</div>
		<div class="helpful_list">
			<ul>
				<?php if($cron_fn_option['helpful_address'] != 'disable'){ ?>
				<li data-help="home">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/home.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>

				<?php if($cron_fn_option['helpful_contact'] == 'enable'){ ?>
				<li data-help="message">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/message.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>

				<?php if($cron_fn_option['helpful_tollfree'] != 'disable'){ ?>
				<li data-help="phone">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/phone.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>

				<?php if($cron_fn_option['helpful_working_hours'] != 'disable'){ ?>
				<li data-help="clock">
					<a href="#"><img class="cron_fn_svg" src="<?php echo esc_url(get_template_directory_uri().'/framework/svg/clock.svg');?>" alt="<?php echo esc_attr__('svg', 'cron');?>" /></a>
				</li>
				<?php } ?>
			</ul>
		</div>
		<div class="social_list">
			<ul>
				<?php if(isset($cron_fn_option['facebook_helpful']) == 1 && $cron_fn_option['facebook_helpful'] != '') { ?>
				<li><a class="facebook" href="<?php echo esc_url($cron_fn_option['facebook_helpful']); ?>" target="_blank"><i class="xcon-facebook"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['twitter_helpful']) == 1 && $cron_fn_option['twitter_helpful'] != '') { ?>
				<li><a class="twitter" href="<?php echo esc_url($cron_fn_option['twitter_helpful']); ?>" target="_blank"><i class="xcon-twitter"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['instagram_helpful']) == 1 && $cron_fn_option['instagram_helpful'] != '') { ?>
				<li><a class="instagram" href="<?php echo esc_url($cron_fn_option['instagram_helpful']); ?>" target="_blank"><i class="xcon-instagram"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['pinterest_helpful']) == 1 && $cron_fn_option['pinterest_helpful'] != '') { ?>
				<li><a class="pinterest" href="<?php echo esc_url($cron_fn_option['pinterest_helpful']); ?>" target="_blank"><i class="xcon-pinterest"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['linkedin_helpful']) == 1 && $cron_fn_option['linkedin_helpful'] != '') { ?>
				<li><a class="linkedin" href="<?php echo esc_url($cron_fn_option['linkedin_helpful']); ?>" target="_blank"><i class="xcon-linkedin"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['behance_helpful']) == 1 && $cron_fn_option['behance_helpful'] != '') { ?>
				<li><a class="behance" href="<?php echo esc_url($cron_fn_option['behance_helpful']); ?>" target="_blank"><i class="xcon-behance"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['vimeo_helpful']) == 1 && $cron_fn_option['vimeo_helpful'] != '') { ?>
				<li><a class="vimeo" href="<?php echo esc_url($cron_fn_option['vimeo_helpful']); ?>" target="_blank"><i class="xcon-vimeo"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['youtube_helpful']) == 1 && $cron_fn_option['youtube_helpful'] != '') { ?>
				<li><a class="youtube" href="<?php echo esc_url($cron_fn_option['youtube_helpful']); ?>" target="_blank"><i class="xcon-youtube"></i></a></li>
				<?php } ?>

				<?php if(isset($cron_fn_option['google_helpful']) == 1 && $cron_fn_option['google_helpful'] != '') { ?>
				<li><a class="google" href="<?php echo esc_url($cron_fn_option['google_helpful']); ?>" target="_blank"><i class="xcon-gplus"></i></a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
	<div class="cron_fn_helpful_bar_open">
		<span class="triangle"></span>
		<span class="closer"></span>
		<div class="fn_list home">
			<span class="top_figure"></span>
			<div class="list_content">
				<?php 
					// renew
					$ALImg = $ALImgURL = $ALImgCallBack = $ALImgDefaultURL = '';
					if(isset($cron_fn_option['helpful_address_list_img'])){
						$ALImg = $cron_fn_option['helpful_address_list_img'];
					}
					if(isset($cron_fn_option['helpful_address_list_img']['url'])){
						$ALImgURL 	= $cron_fn_option['helpful_address_list_img']['url'];
					}
					if(isset($ALImg) && isset($ALImgURL)){
						if($ALImgURL !== ''){
							$ALImgDefaultURL 	= $ALImgURL;
							$ALImgCallBack		= '<div class="al_img"><div class="abs_img" data-fn-bg-img="'.$ALImgDefaultURL.'"></div><img src="'.get_template_directory_uri().'/framework/img/thumb/thumb-320-200.jpg'.'" alt="'.esc_attr__("thumb", "cron").'" /></div>';
						}
					}
					if(isset($cron_fn_option['helpful_address_list_title'])){
						$titleA = $cron_fn_option['helpful_address_list_title'];
					}else{
						$titleA = esc_html('Head Office in New-York', 'cron');
					}
					if(isset($cron_fn_option['helpful_address_list_content'])){
						$descA = $cron_fn_option['helpful_address_list_content'];
					}else{
						$descA = esc_html('775 New York Ave, Brooklyn, NY 11203', 'cron');
					}
					$listAddress = '<div class="address_list">';
					$listAddress .= '<div class="item">'.$ALImgCallBack.'<div class="al_title"><h3>'.$titleA.'</h3><p>'.$descA.'</p></div></div>';
					$listAddress .= '</div>';
					echo wp_kses_post($listAddress);
				?>
			</div>
			<div class="list_bg"></div>
		</div>
		<div class="fn_list message">
			<span class="top_figure"></span>
			<div class="list_content">
				<?php get_template_part('framework/modal/quick-contact');?>
			</div>
			<div class="list_bg"></div>
		</div>
		<div class="fn_list phone">
			<span class="top_figure"></span>
			<div class="list_content">
				<?php 
					$tollfree_img = get_template_directory_uri().'/framework/img/call.png';
					$tollfree_img_config = $tollfree_img_configURL = '';
					if(isset($cron_fn_option['helpful_tollfree_img'])){
						$tollfree_img_config 	= $cron_fn_option['helpful_tollfree_img'];
					}
					if(isset($cron_fn_option['helpful_tollfree_img']['url'])){
						$tollfree_img_configURL = $cron_fn_option['helpful_tollfree_img']['url'];
					}
					if(isset($tollfree_img_config) && isset($tollfree_img_configURL)){
						if($tollfree_img_configURL !== ''){
							$tollfree_img = $tollfree_img_configURL;
						}
					}
				?>
				<div class="toll_free">
					<div class="img_holder">
						<img src="<?php echo esc_url($tollfree_img); ?>" alt="<?php echo esc_attr__('img', 'cron');?>" />
					</div>
					<div class="title_holder">
						<h3>
							<?php 
								if(isset($cron_fn_option['helpful_tollfree_title'])){ 
									echo wp_kses_post($cron_fn_option['helpful_tollfree_title']);
								}else{ 
									esc_html_e('Toll Free', 'cron');
								} 
							?>
						</h3>
						<h5>
							<?php 
								if(isset($cron_fn_option['helpful_tollfree_subtitle'])){ 
									echo wp_kses_post($cron_fn_option['helpful_tollfree_subtitle']);
								}else{ 
									echo '1-800-987-6543';
								} 
							?>
						</h5>
					</div>
				</div>
			</div>
			<div class="list_bg"></div>
		</div>
		<div class="fn_list clock">
			<span class="top_figure"></span>
			<div class="list_content">
				<div class="working_hours">
					<div class="title_holder">
						<h3>
							<?php 
								if(isset($cron_fn_option['helpful_working_hours_title'])){ 
									echo wp_kses_post($cron_fn_option['helpful_working_hours_title']);
								}else{ 
									esc_html_e('Working Hours', 'cron');
								} 
							?>
						</h3>
						<p>
							<?php 
								if(isset($cron_fn_option['helpful_working_hours_subtitle'])){ 
									echo wp_kses_post($cron_fn_option['helpful_working_hours_subtitle']);
								}else{ 
									esc_html_e('We are happy to meet you during our working hours. Please make an appointment.', 'cron');
								} 
							?>
						</p>
					</div>
					<div class="days_holder">
						<ul>
							<?php 
								if(isset($cron_fn_option['helpful_working_hours_list']) && !empty($cron_fn_option['helpful_working_hours_list'])){
									$WHArray 	= $cron_fn_option['helpful_working_hours_list'];
									$WHItem 	= '';
									foreach($WHArray as $WHChild){
										$titleA 	= $WHChild['title'];
										$descA 		= $WHChild['description'];
										$WHItem .= '<li><span class="day">'.$titleA.'</span><span class="hours">'.$descA.'</span></li>';
									}
									echo wp_kses_post($WHItem);
								}
							?>
						</ul>
					</div>
				</div>
			</div>
			<div class="list_bg"></div>
		</div>
	</div>
	<div class="cron_fn_helpful_bar_bg"><span></span></div>
</div>