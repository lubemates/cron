<?php 
	global $cron_fn_option, $post;
	
	// LOGO ----------------------------------------------------------------------------------
	$defaultLogo 	= get_template_directory_uri().'/framework/img/header-popup-logo.png';
	
	$logoDesktop 	= $logoDesktopURL = '';
	if(isset($cron_fn_option['header_opener_logo'])){
		$logoDesktop 		= $cron_fn_option['header_opener_logo'];
	}
	if(isset($cron_fn_option['header_opener_logo']['url'])){
		$logoDesktopURL 	= $cron_fn_option['header_opener_logo']['url'];
	}
	if(isset($logoDesktop) && isset($logoDesktopURL)){
		if($logoDesktopURL !== ''){
			$defaultLogo = $logoDesktopURL;
		}
	}
	
	$main_nav 	= array('theme_location'  => 'main_menu','menu_class' => 'cron_fn_main_nav vert_nav');

	$copyrightText 			= '';
	if(isset($cron_fn_option['navigation_popup_text'])){
		$copyrightText		= $cron_fn_option['navigation_popup_text'];
	}
	
?>
<div class="cron_fn_header_right_opener"></div>
<div class="cron_fn_header_opener">
	<span class="closer"></span>
	<div class="cron_fn_header_opener_in">
		<div class="ho_logo">
			<a href="<?php echo esc_url(home_url('/')); ?>">
				<img class="desktop_logo" src="<?php echo esc_url($defaultLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
			</a>
		</div>
		<div class="ho_menu">
			<?php if(has_nav_menu('main_menu')){ wp_nav_menu( $main_nav );} else{echo '<ul class="vert_nav"><li><a href="">'.esc_html__('No menu assigned', 'constructify').'</a></li></ul>';}?>
		</div>
		<div class="ho_footer">
			<?php get_template_part( 'inc/cron_fn_sharebox_open'); ?>
			<div class="ho_cright">
				<p><?php echo esc_html($copyrightText);?></p>
			</div>
		</div>
	</div>
</div>