<?php 
	global $cron_fn_option, $post;

	// ------------------------------------------------------------------------------------------------
	// DARK LOGO DEFAULT URL --------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------
	$defaultDarkLogo 			= get_template_directory_uri().'/framework/img/desktop-dark-logo.png';
	$retinaDarkLogo 			= get_template_directory_uri().'/framework/img/retina-dark-logo.png';
	
	// ------------------------------------------------------------------------------------------------
	// DARK SIMPLE LOGO -------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------
	$logoDarkDesktop 			= $logoDarkDesktopURL = '';
	if(isset($cron_fn_option['desktop_dark_logo'])){
		$logoDarkDesktop 		= $cron_fn_option['desktop_dark_logo'];
	}
	if(isset($cron_fn_option['desktop_dark_logo']['url'])){
		$logoDarkDesktopURL 	= $cron_fn_option['desktop_dark_logo']['url'];
	}
	if(isset($logoDarkDesktop) && isset($logoDarkDesktopURL)){
		if($logoDarkDesktopURL !== ''){
			$defaultDarkLogo 	= $logoDarkDesktopURL;
		}
	}
	// ------------------------------------------------------------------------------------------------
	// DARK RETINA LOGO -------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------
	$logoDarkRetina 			= $logoDarkRetinaURL = '';
	if(isset($cron_fn_option['retina_dark_logo'])){
		$logoDarkRetina 		= $cron_fn_option['retina_dark_logo'];
	}
	if(isset($cron_fn_option['retina_dark_logo']['url'])){
		$logoDarkRetinaURL 		= $cron_fn_option['retina_dark_logo']['url'];
	}
	if(isset($logoDarkRetina) && isset($logoDarkRetinaURL)){
		if($logoDarkRetinaURL !== ''){
			$retinaDarkLogo 	= $logoDarkRetinaURL;
		}
	}

	// ------------------------------------------------------------------------------------------------
	// LIGHT LOGO DEFAULT URL --------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------
	$defaultLightLogo 			= get_template_directory_uri().'/framework/img/desktop-light-logo.png';
	$retinaLightLogo 			= get_template_directory_uri().'/framework/img/retina-light-logo.png';
	
	// ------------------------------------------------------------------------------------------------
	// LIGHT SIMPLE LOGO -------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------
	$logoLightDesktop 			= $logoLightDesktopURL = '';
	if(isset($cron_fn_option['desktop_light_logo'])){
		$logoLightDesktop 		= $cron_fn_option['desktop_light_logo'];
	}
	if(isset($cron_fn_option['desktop_light_logo']['url'])){
		$logoLightDesktopURL 	= $cron_fn_option['desktop_light_logo']['url'];
	}
	if(isset($logoLightDesktop) && isset($logoLightDesktopURL)){
		if($logoLightDesktopURL !== ''){
			$defaultLightLogo 	= $logoLightDesktopURL;
		}
	}
	// ------------------------------------------------------------------------------------------------
	// LIGHT RETINA LOGO -------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------
	$logoLightRetina 			= $logoLightRetinaURL = '';
	if(isset($cron_fn_option['retina_light_logo'])){
		$logoLightRetina 		= $cron_fn_option['retina_light_logo'];
	}
	if(isset($cron_fn_option['retina_light_logo']['url'])){
		$logoLightRetinaURL 	= $cron_fn_option['retina_light_logo']['url'];
	}
	if(isset($logoLightRetina) && isset($logoLightRetinaURL)){
		if($logoLightRetinaURL !== ''){
			$retinaLightLogo 	= $logoLightRetinaURL;
		}
	}

	
	// navigation skin
	$nav_skin 					= 'light';
	if(isset($cron_fn_option['nav_skin'])){
		$nav_skin 				= $cron_fn_option['nav_skin'];
	}
	if(function_exists('rwmb_meta')){
		$nav_skin 				= get_post_meta(get_the_ID(),'cron_fn_page_nav_color', true);
		if($nav_skin === 'default' && isset($cron_fn_option['nav_skin'])){
			$nav_skin 			= $cron_fn_option['nav_skin'];
		}
	}
	if(isset($cron_fn_option['nav_skin'])){
		if($nav_skin === 'undefined' || $nav_skin === ''){
			$nav_skin 			= $cron_fn_option['nav_skin'];
		}
	}
	if($nav_skin == ''){
		$nav_skin 	= 'light';
	}
	switch($nav_skin){
		case 'dark':
		case 'transdark':
		case 'nobglight': 	$defaultLogo = $defaultLightLogo; $retinaLogo 	= $retinaDarkLogo; break;
		case 'light':
		case 'translight':
		case 'nobgdark': 	$defaultLogo = $defaultDarkLogo; $retinaLogo 	= $retinaDarkLogo; 	break;
	}
?>
   
<div class="cron_fn_header_wrapper container" data-skin="<?php echo esc_attr($nav_skin);?>">
	<div class="cron_fn_header">
		<div class="menu_logo">
			<a href="<?php echo esc_url(home_url('/')); ?>">
				<img class="desktop_logo" src="<?php echo esc_url($defaultLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
				<img class="retina_logo" src="<?php echo esc_url($retinaLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
			</a>
		</div>
		<div class="menu_hamb">
			<div class="hamburger hamburger--collapse-r">
				<div class="hamburger-box">
					<div class="hamburger-inner"></div>
				</div>
			</div>
			<span>Menu</span>
		</div>

	</div>
</div>