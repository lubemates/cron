<?php
/*
Name: Cron
Description: Custom Love Posts
Author: Frenify
Author URI: http://themeforest.net/user/frenify
*/
global $cron_fn_option, $post; $src = '';

$postid = get_the_ID();
if (has_post_thumbnail()) {
	$post_thumbnail_id = get_post_thumbnail_id( $postid );
	$src = wp_get_attachment_image_src( $post_thumbnail_id, 'full');
	$src = $src[0];
}

?>
<?php if(isset($cron_fn_option)){?>
<div class="cron_fn_share_open_icons">
	<ul>
		<?php if(isset($cron_fn_option['share_facebook']) == 1 && $cron_fn_option['share_facebook'] != 'disable') { ?>
		<li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>" target="_blank"><?php echo esc_html__('Facebook', 'cron');?></a></li>
		<?php } ?>

		<?php if(isset($cron_fn_option['share_twitter']) == 1 && $cron_fn_option['share_twitter'] != 'disable') { ?>
		<li><a href="https://twitter.com/share?url=<?php the_permalink();?>"  target="_blank"><?php echo esc_html__('Twitter', 'cron');?></a></li>
		<?php } ?>

		<?php if(isset($cron_fn_option['share_google']) == 1 && $cron_fn_option['share_google'] != 'disable') { ?>
		<li><a href="https://plus.google.com/share?url=<?php the_permalink();?>" target="_blank"><?php echo esc_html__('Google', 'cron');?></a></li>
		<?php } ?>

		<?php if(isset($cron_fn_option['share_pinterest']) == 1 && $cron_fn_option['share_pinterest'] != 'disable') { ?>
		<li><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink();?>&amp;media=<?php if($src != ''){echo esc_url($src);} ?>" target="_blank"><?php echo esc_html__('Pinterest', 'cron');?></a></li>
		<?php } ?>

		<?php if(isset($cron_fn_option['share_linkedin']) == 1 && $cron_fn_option['share_linkedin'] != 'disable') { ?>
		<li><a href="http://linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink();?>&amp;" target="_blank"><?php echo esc_html__('LinkedIn', 'cron');?></a></li>
		<?php } ?>

		<?php if(isset($cron_fn_option['share_email']) == 1 && $cron_fn_option['share_email'] != 'disable') { ?>
		<li><a href="mailto:?amp;body=<?php the_permalink() ?>" target="_blank"><?php echo esc_html__('Email', 'cron');?></a></li>
		<?php } ?>

		<?php if(isset($cron_fn_option['share_vk']) == 1 && $cron_fn_option['share_vk'] != 'disable') { ?>
		<li><a href="https://www.vk.com/sharer.php?url=<?php the_permalink();?>" target="_blank"><?php echo esc_html__('VKontakte', 'cron');?></a></li>
		<?php } ?>

	</ul>
</div>
<?php } ?>