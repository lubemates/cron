<?php
global $post, $cron_fn_option;

// TITLE
if(isset($cron_fn_option['helpful_contact_title'])){
	$title = $cron_fn_option['helpful_contact_title'];
}else{
	$title = esc_html('Request a Quote', 'cron');
}

// DESCRIPTION
if(isset($cron_fn_option['helpful_contact_content'])){
	$desc = $cron_fn_option['helpful_contact_content'];
}else{
	$desc = esc_html('Looking for a quality and affordable builder for your next project?', 'cron');
}

// NAME PLACEHOLDER
if(isset($cron_fn_option['helpful_contact_name_placeholder'])){
	$namePlaceholder 		= $cron_fn_option['helpful_contact_name_placeholder'];
}else{
	$namePlaceholder 		= esc_html('Your Name', 'cron');
}

// E-MAIL PLACEHOLDER
if(isset($cron_fn_option['helpful_contact_email_placeholder'])){
	$emailPlaceholder 		= $cron_fn_option['helpful_contact_email_placeholder'];
}else{
	$emailPlaceholder 		= esc_html('E-Mail Address', 'cron');
}

// SUBJECT PLACEHOLDER
if(isset($cron_fn_option['helpful_contact_subject_placeholder'])){
	$subjectPlaceholder 	= $cron_fn_option['helpful_contact_subject_placeholder'];
}else{
	$subjectPlaceholder 	= esc_html('Main Subject', 'cron');
}

// MESSAGE PLACEHOLDER
if(isset($cron_fn_option['helpful_contact_subject_placeholder'])){
	$messagePlaceholder 	= $cron_fn_option['helpful_contact_message_placeholder'];
}else{
	$messagePlaceholder 	= esc_html('Message', 'cron');
}

// SEND PLACEHOLDER
if(isset($cron_fn_option['helpful_contact_sending_button_value'])){
	$sendPlaceholder 		= $cron_fn_option['helpful_contact_sending_button_value'];
}else{
	$sendPlaceholder 		= esc_html('Send Message', 'cron');
}


?>
<!-- Following HTML code is used to display Reservation form after clicking on the "Book Online" button. -->
<div class="cron_fn_quick_contact" data-url="<?php echo esc_url(cron_PLUGIN_URL);?>">
    <h3><?php echo esc_html($title); ?></h3>
    <p><?php echo esc_html($desc); ?></p>
    <form action="/" method="post" class="cron_fn_quick_contact_form">
        
        <input type="hidden" class="receiver" data-email="<?php echo esc_html($cron_fn_option['helpful_contact_receiver_email']); ?>" />
        
        <div class="row_wrap">
        	<div class="inputs">
        		<div>
					<input type="text" class="name" placeholder="<?php echo esc_attr($namePlaceholder);?>" />
				</div>
				<div>
					<input type="text" class="email" placeholder="<?php echo esc_attr($emailPlaceholder);?>" data-invalidemail="<?php esc_html_e('* Invalid Email *', 'cron'); ?>" />
				</div>
				<div>
					<input type="text" class="subject" placeholder="<?php echo esc_attr($subjectPlaceholder);?>" />
				</div>
			</div>
			<textarea class="message" placeholder="<?php echo esc_attr($messagePlaceholder);?>" cols="6" rows="6"></textarea>
			<input type="button" class="cron_fn_quick_contact_submit" value="<?php echo esc_attr($sendPlaceholder);?>" />
        </div>
        
        <div class="returnmessage" data-success="<?php esc_html_e('Your Query has been received. We will contact you soon.', 'cron'); ?>"></div>
        
        <div class="empty_notice">
            <span><?php esc_html_e('* Please Fill Required Fields *', 'cron'); ?></span>
        </div>
        
    </form>
</div>