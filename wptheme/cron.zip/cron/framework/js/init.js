/*
 * Copyright (c) 2019 gho5t7m
 * Author: gho5t7m
 * This file is made for CURRENT TEMPLATE
*/


jQuery(document).ready(function(){

	"use strict";
	
	// here all ready functions
	cron_fn_mainMenuOpener();
	cron_fn_langOpener();
	cron_fn_imgToSvg();
	cron_fn_dataBgImg();
	cron_fn_quick_contact();
	cron_fn_movingLangCalc();
	cron_fn_mobileHelpfulOpener();
	cron_fn_hambClick();
	cron_fn_versubmenu();
	cron_fn_totop();
	cron_fn_postSlider();
	cron_fn_lightbox();
	cron_fn_estimateWidget();
	cron_fn_ajaxPagination();
	cron_fn_projectFilter();
	cron_fn_justified_images();
	frenify_fn_sticky_sidebar();
	cron_fn_allpages_height();
	cron_fn_isotope();
	cron_fn_postShapes();
	cron_fn_helpfulOpener();
	cron_fn_headerPopupMenuHeight();
	cron_fn_fixedsub();
	
	// here all resize functions
	jQuery(window).on('resize',function(e){
		e.preventDefault();
		cron_fn_headerPopupMenuHeight();
		cron_fn_movingLangCalc();
		cron_fn_estimateWidget();
		cron_fn_allpages_height();
		cron_fn_isotope();
		cron_fn_postShapes();
	});
	
	
	
	// here all load functions
	jQuery(window).on('load', function(e) {
		e.preventDefault();
		cron_fn_isotope();
		setTimeout(function(){
			cron_fn_isotope();
		},100);
	});
	
	
	
	// here all scroll functions
	jQuery(window).on('scroll', function(e) {
		e.preventDefault();
		cron_fn_totopScroll();
    });
	
	setTimeout(function(){
		cron_fn_isotope();
	},4500);
});
// -----------------------------------------------------
// ------------    FIXED MOVING SUBMENU    -------------
// -----------------------------------------------------
function cron_fn_fixedsub(){
	"use strict";
	var fixedsub 			= jQuery('#cron_fn_fixedsub');
	var li					= jQuery('.cron_fn_header_opener_in .ho_menu ul.vert_nav > li');
	var leftpartW			= jQuery('.cron_fn_menubar').width();
	var rightpart			= jQuery('.cron_fn_rightpart, .cron_fn_header_opener_in .ho_logo, .cron_fn_header_opener_in .ho_footer');
	var adminBar 			= 0;
	var vertNav				= jQuery('.cron_fn_header_opener_in .ho_menu ul.vert_nav');
	if(jQuery('body').hasClass('admin-bar')){
		adminBar  = 32;
	}
	
	
	li.on('mouseenter', function(){
		var parentLi 		= jQuery(this);
		var subMenu			= parentLi.children('ul.sub-menu');
		var subMenuHtml 	= subMenu.html();
		//parentLi;
		if(subMenu.length){
			li.removeClass('hovered');
			parentLi.addClass('hovered').parent().addClass('hovered');
			fixedsub.removeClass('opened').children('ul').html('').html(subMenuHtml);
			fixedsub.addClass('opened');
		}else{
			fixedsub.removeClass('opened');
			parentLi.removeClass('hovered').parent().removeClass('hovered');
		}
		var topOffSet 		= parentLi.offset().top;
		var menuBar			= jQuery('.cron_fn_header_opener_in');
		var menuBarOffSet	= menuBar.offset().top;
		var asd				= topOffSet-menuBarOffSet+adminBar;
		leftpartW = jQuery('.cron_fn_menubar').width() ;
		
		fixedsub.css({top:asd,left:vertNav.width()+30});
		abc();
	});
	function abc(){
		rightpart.on('mouseenter', function(){
			fixedsub.removeClass('opened');
			li.removeClass('hovered').parent().removeClass('hovered');
		});
		jQuery('.cron_fn_header_opener_in .ho_menu').on('mouseleave',function(){
			fixedsub.removeClass('opened');
			li.removeClass('hovered').parent().removeClass('hovered');
		});
		fixedsub.on('mouseenter',function(){
			fixedsub.addClass('opened');
			li.addClass('hovered').parent().addClass('hovered');
		});
	}
	abc();
}
function cron_fn_headerPopupMenuHeight(){
	"use strict";
	var H				= jQuery(window).height();
	var hoMenu 			= jQuery('.cron_fn_header_opener_in .ho_menu');
	var navigation		= jQuery('.cron_fn_header_opener_in .ho_menu ul.vert_nav');
	var hoFooterH		= jQuery('.cron_fn_header_opener_in .ho_footer').outerHeight();
	var hoLogoH			= jQuery('.cron_fn_header_opener_in .ho_logo').outerHeight();
	if(navigation.outerHeight() >= H-60-hoFooterH-hoLogoH){
		hoMenu.css({height:H-60-hoFooterH-hoLogoH});
	}else{
		hoMenu.css({height:'auto'});
	}
	if(jQuery().niceScroll){
		navigation.niceScroll({
			touchbehavior:false,
			cursorwidth:0,
			autohidemode:true,
			cursorborder:"0px solid #333"
		});
	}
}
function cron_fn_helpfulOpener(){
	"use strict";
	var element = jQuery('.cron_fn_helpful_bar');
			
	if(element.length){
		var item 			= element.find('.helpful_list li');
		var helpfulBar		= element.find('.cron_fn_helpful_bar_open');
		var helpfulLists	= element.find('.cron_fn_helpful_bar_open > div');
		var triangle 		= helpfulBar.find('.triangle');
		var opener			= jQuery('.cron_fn_bghelp');
		var body			= jQuery('body');
		item.on('click',function(){
			var eachItem			= jQuery(this);
			var liTopOffSet			= eachItem.offset().top;
			var elementTopOffSet 	= element.offset().top;
			var topOffSet	 		= liTopOffSet - elementTopOffSet-6;
			var minHeight 			= liTopOffSet - elementTopOffSet+26;
			triangle.css({top:topOffSet});
			helpfulLists.css({minHeight:minHeight});
			if(eachItem.hasClass('clicked')){
				opener.removeClass('opened');
				body.removeClass('disabled_scroll');
				item.removeClass('clicked');
				helpfulLists.removeClass('clicked');
				helpfulBar.removeClass('clicked');
			}else{
				var attrClass		= eachItem.attr('data-help');		
				var overlayChild	= element.find('.cron_fn_helpful_bar_open .' + attrClass);
				opener.addClass('opened');
				body.addClass('disabled_scroll');
				
				item.removeClass('clicked');
				eachItem.addClass('clicked');
				helpfulLists.removeClass('clicked');
				helpfulBar.addClass('clicked');
				overlayChild.addClass('clicked');
			}
			return false;
		});
		jQuery('.cron_fn_helpful_bar_open span.closer,.cron_fn_bghelp').on('click',function(){
			opener.removeClass('opened');
			item.removeClass('clicked');
			helpfulLists.removeClass('clicked');
			helpfulBar.removeClass('clicked');
			body.removeClass('disabled_scroll');
		});
	}
}
// -----------------------------------------------------
// --------------    LANGUAGE OPENER    ----------------
// -----------------------------------------------------
function cron_fn_langOpener(){
	"use strict";
	var lang 		= jQuery('.cron_fn_custom_lang_switcher');
	if(lang.length){
		var click 		= lang.find('span.click');
		var box 		= lang.find('ul');
		var location	= window.location.href;
		var myLocation	= '^http://cron.frenify.com/1/';
		var langTO		= lang.offset().top;
		var langLO		= lang.offset().left;
		var wrapper		= jQuery('.cron_fn_wrapper_all');
		var newAttr 	= '';
		if(lang.hasClass('frenify_url')){
			newAttr	= 'frenify_url';
		}
		var extraH = 0;
		if(jQuery('body').hasClass('admin-bar')){
			extraH	= 32;
		}
		wrapper.append('<div class="cron_fn_moving_lang ' + newAttr + '"><ul>'+box.html() + '</ul></div>');
		var movingLang 	= jQuery('.cron_fn_moving_lang');
		var box2		= movingLang.find('ul');
		movingLang.css({position:'absolute',left:langLO + 'px',top:langTO - extraH + 30 + 'px'});

		if(lang.length){
			click.on('click',function(){
				if(lang.hasClass('opened')){
					movingLang.removeClass('opened');
					lang.removeClass('opened');
				}else{
					lang.addClass('opened');
					movingLang.addClass('opened');
				}
			});
			if(location.match(myLocation)){
				box2.find('li').on('click',function(){
					var element			= jQuery(this);
					var spanHTML 		= element.find('span').html();
					var oldChildHTML 	= box2.find('li.active').html();
					if(element.hasClass('active')){
						// do nothing
					}else{
						box2.find('li.active').removeClass('active').html('<a href="#">' + oldChildHTML + '</a>');
						element.addClass('active').html('<span>' + spanHTML + '</span>');
						lang.removeClass('opened');
						click.html(spanHTML);
					}

					return false;
				});
			}
			jQuery(window).on('click',function() {
				lang.removeClass('opened');
				movingLang.removeClass('opened');
			});
			box2.on('click',function(event){
				event.stopPropagation();
			});
			lang.on('click',function(event){
				event.stopPropagation();
			});
		}
	}
	
}
function cron_fn_movingLangCalc(){
	"use strict";
	var movingLang 	= jQuery('.cron_fn_moving_lang');
	
	if(movingLang.length){
		var lang 		= jQuery('.cron_fn_custom_lang_switcher');
		var langTO		= lang.offset().top;
		var langLO		= lang.offset().left;
		var extraH = 0;
		if(jQuery('body').hasClass('admin-bar')){
			extraH	= 32;
		}
		movingLang.css({position:'absolute',left:langLO + 'px',top:langTO - extraH + 30 + 'px'});
	}
}
// -----------------------------------------------------
// ---------------    IMAGE TO SVG    ------------------
// -----------------------------------------------------
function cron_fn_imgToSvg(){
	"use strict";
	
	jQuery('img.cron_fn_svg').each(function(){
		var $img 		= jQuery(this);
		var imgClass	= $img.attr('class');
		var imgURL		= $img.attr('src');

		jQuery.get(imgURL, function(data) {
			var $svg = jQuery(data).find('svg');
			if(typeof imgClass !== 'undefined') {
				$svg = $svg.attr('class', imgClass+' replaced-svg');
			}
			$img.replaceWith($svg);

		}, 'xml');

	});
}
function cron_fn_closeFixedHelpful(){
	"use strict";
	var fixedBox	= jQuery('.cron_fn_helpful_fixed');
	var parent		= jQuery('.cron_fn_topbar .helpful_list');
	fixedBox.find('.fn_list.clicked').removeClass('clicked').slideUp();
	fixedBox.find('.clicked').removeClass('clicked');
	fixedBox.addClass('ready-to-close');
	setTimeout(function(){
		fixedBox.addClass('closing');
	},500);
	setTimeout(function(){
		fixedBox.removeClass('opened closing');
		parent.removeClass('clicked');
	},1000);
	setTimeout(function(){
		fixedBox.removeClass('ready-to-close');
	},1001);
}
// -----------------------------------------------------
// ----------    ALL DATA BACKGROUND IMAGE    ----------
// -----------------------------------------------------
function cron_fn_dataBgImg(){
	"use strict";
	var bgImage = jQuery('*[data-fn-bg-img]');
	bgImage.each(function(){
		var element = jQuery(this);
		var attrBg	= element.attr('data-fn-bg-img');
		var bgImg	= element.data('fn-bg-img');
		if(typeof(attrBg) !== 'undefined'){
			element.css({backgroundImage:'url('+bgImg+')'});
		}
	});
}
// -----------------------------------------------------
// -----------    HELPFUL QUICK CONTACT    -------------
// -----------------------------------------------------
function cron_fn_quick_contact(){
	"use strict";
	
	jQuery(".cron_fn_quick_contact_submit").on('click', function(){
		var receiver 	= jQuery(".cron_fn_quick_contact_form .receiver").data('email');
		var name 		= jQuery(".cron_fn_quick_contact_form .name").val();
		var email 		= jQuery(".cron_fn_quick_contact_form .email").val();
		var subject 	= jQuery(".cron_fn_quick_contact_form .subject").val();
		var message 	= jQuery(".cron_fn_quick_contact_form .message").val();
		var success     = jQuery(".cron_fn_quick_contact_form .returnmessage").data('success');
		var url 		= jQuery(".cron_fn_quick_contact").data('url');
	
		jQuery(".cron_fn_quick_contact_form .returnmessage").empty(); //To empty previous error/success message.
		//checking for blank fields
		if(name===''||email===''||message===''){
			jQuery('div.empty_notice').slideDown(500).delay(2000).slideUp(500);
		}
		else{

			// Returns successful data submission message when the entered information is stored in database.
			jQuery.post(url,{xx_receiver:receiver, xx_name: name, xx_email: email, xx_subject: subject, xx_message:message}, function(data) {
				
				jQuery(".cron_fn_quick_contact_form .returnmessage").append(data);//Append returned message to message paragraph
				
				if(jQuery(".cron_fn_quick_contact_form .returnmessage span.contact_error").length){
					jQuery(".cron_fn_quick_contact_form .returnmessage").slideDown(500).delay(2000).slideUp(500);	
				}else{
					jQuery(".cron_fn_quick_contact_form .returnmessage").append("<span class='book_success'>"+ success +"</span>");
					jQuery(".cron_fn_quick_contact_form .returnmessage").slideDown(500).delay(4000).slideUp(500);
					setTimeout(function(){
						cron_fn_closeFixedHelpful();
					}, 5000);

				}
				
				if(data === ""){
					jQuery(".cron_fn_quick_contact_form")[0].reset();//To reset form fields on success
				}
			});
		}
		return false;
	});
}
function cron_fn_mainMenuOpener(){
	"use strict";
	var element 			= jQuery('.cron_fn_header_wrapper');
			
	if(element.length){
		var button			= element.find('.menu_hamb');
		var hamburger		= element.find('.hamburger');
		// -------------------------
		
		button.on('click',function(){
			if(hamburger.hasClass('is-active')){
				hamburger.removeClass('is-active');
				jQuery('body').removeClass('header_opened');
			}else{
				hamburger.addClass('is-active');
				jQuery('body').addClass('header_opened');
			}
			
			return false;
		});
	}
	var anotherBtn			= jQuery('.cron_fn_header_opener span.closer');
	anotherBtn.on('click',function(){
		hamburger.removeClass('is-active');
		jQuery('body').removeClass('header_opened');
	});
}
// -----------------------------------------------------
// -----------    MOBILE HELPFUL OPENER    -------------
// -----------------------------------------------------
function cron_fn_mobileHelpfulOpener(){
	"use strict";
	var element = jQuery('.cron_fn_mobilemenu_wrap');
			
	if(element.length){
		var item 			= element.find('.helpful_list li');
		var helpfulBar		= element.find('.info_bar_dropdown');
		var helpfulLists	= element.find('.info_bar_dropdown > div');
		
		// added after author notice
		var mobMenu			= jQuery('.cron_fn_mobilemenu_wrap .mobilemenu');
		var hamburger		= jQuery('.cron_fn_mobilemenu_wrap .hamburger');
		// -------------------------
		
		item.on('click',function(){
			var eachItem			= jQuery(this);
			var attrClass			= eachItem.attr('data-help');
			var helpfulList			= element.find('.info_bar_dropdown .' + attrClass);
			
			// added after author notice
			if(mobMenu.hasClass('opened')){
				hamburger.removeClass('is-active');
				mobMenu.removeClass('opened').slideUp();
			}
			// -------------------------
			
			if(helpfulBar.hasClass('clicked')){
				if(eachItem.hasClass('clicked')){
					eachItem.removeClass('clicked');
					helpfulList.removeClass('clicked').slideUp();
					setTimeout(function(){
						helpfulBar.removeClass('clicked').hide();
					},500);
				}else{
					item.removeClass('clicked');
					helpfulLists.removeClass('clicked').slideUp();
					eachItem.addClass('clicked');
					helpfulList.addClass('clicked').slideDown();
				}
			}else{
				helpfulBar.addClass('clicked').show();
				eachItem.addClass('clicked');
				helpfulList.addClass('clicked').slideDown();
			}
			return false;
		});
	}
}

// -----------------------------------------------------
// -----------------    HAMBURGER    -------------------
// -----------------------------------------------------
function cron_fn_hambClick(){
	"use strict";
	
	var hamburger		= jQuery('.cron_fn_mobilemenu_wrap .hamburger');
	
	// added after author notice
	var helpfulDD		= jQuery('.cron_fn_mobilemenu_wrap .info_bar_dropdown');
	var helpfulLi		= jQuery('.cron_fn_mobilemenu_wrap .helpful_list li');
	var fnList			= jQuery('.cron_fn_mobilemenu_wrap .info_bar_dropdown .fn_list');
	var infoBar			= jQuery('.cron_fn_mobilemenu_wrap .info_bar');
	// -------------------------
	
	hamburger.on('click',function(){
		var element 	= jQuery(this);
		var menupart	= jQuery('.cron_fn_mobilemenu_wrap .mobilemenu');
		
		// added after author notice
		if(infoBar.length){
			if(helpfulDD.hasClass('clicked')){
				helpfulDD.removeClass('clicked').slideUp();
				fnList.slideUp();
				helpfulLi.removeClass('clicked');
			}
		}
		// -------------------------
		
		if(element.hasClass('is-active')){
			element.removeClass('is-active');
			menupart.removeClass('opened');
			menupart.slideUp(500);
		}else{
			element.addClass('is-active');
			menupart.addClass('opened');
			menupart.slideDown(500);
		}return false;
	});
}
// -----------------------------------------------------
// -------------    VERTICAL SUBMENU    ----------------
// -----------------------------------------------------
function cron_fn_versubmenu(){
	"use strict";
	
	var nav 					= jQuery('ul.vert_menu_list, .widget_nav_menu ul.menu');
	
	nav.each(function(){
		jQuery(this).find('a').on('click', function(e){
			var element 			= jQuery(this);
			var parentItem			= element.parent('li');
			var parentItems			= element.parents('li');
			var parentUls			= parentItem.parents('ul.sub-menu');
			var subMenu				= element.next();
			var allSubMenusParents 	= nav.find('li');

			allSubMenusParents.removeClass('opened');

			if(subMenu.length){
				e.preventDefault();

				if(!(subMenu.parent('li').hasClass('active'))){
					if(!(parentItems.hasClass('opened'))){parentItems.addClass('opened');}

					allSubMenusParents.each(function(){
						var el = jQuery(this);
						if(!el.hasClass('opened')){el.find('ul.sub-menu').slideUp();}
					});

					allSubMenusParents.removeClass('active');
					parentUls.parent('li').addClass('active');
					subMenu.parent('li').addClass('active');
					subMenu.slideDown();


				}else{
					subMenu.parent('li').removeClass('active');
					subMenu.slideUp();
				}
				return false;
			}
		});
	});
}
// -----------------------------------------------------
// --------------------    TOTOP    --------------------
// -----------------------------------------------------
function cron_fn_totop(){
	"use strict";
	var totop		= jQuery('a.cron_fn_totop');
	if(totop.length){
		totop.on('click', function(e) {
			e.preventDefault();		
			jQuery("html, body").animate({ scrollTop: 0 }, 'slow');
			return false;
		});
	}
}
function cron_fn_totopScroll(){
	"use strict";
	var totop		= jQuery('a.cron_fn_totop');
	if(totop.length){
		var topOffSet 	= totop.offset().top;
		if(topOffSet > 1000){
			totop.addClass('scrolled');
		}else{
			totop.removeClass('scrolled');
		}
	}
}
// -----------------------------------------------------
// -----------------    SLIDER POST    -----------------
// -----------------------------------------------------
function cron_fn_postSlider(){
	"use strict";
	var slider = jQuery('.cron_fn_blog_single .fn-format-gallery .owl-carousel');
	if(jQuery().owlCarousel){
		slider.owlCarousel({
			loop:false,
			margin:10,
			nav:true,
			items: 1,
			dots: false
		});
	}
}
// -----------------------------------------------------
// ---------------   GALLERY LIGHTBOX    ---------------
// -----------------------------------------------------
function cron_fn_lightbox(){
	"use strict";
	if(jQuery().lightGallery){
		// FIRST WE SHOULD DESTROY LIGHTBOX FOR NEW SET OF IMAGES
		
		var gallery = jQuery('.frenify_fn_lightbox');
		
		gallery.each(function(){
			var element = jQuery(this);
			element.lightGallery(); // binding
			if(element.length){element.data('lightGallery').destroy(true); }// destroying
			jQuery(this).lightGallery({
				selector: ".lightbox",
				thumbnail: 1,
				loadYoutubeThumbnail: !1,
				loadVimeoThumbnail: !1,
				showThumbByDefault: !1,
				mode: "lg-fade",
				download:!1,
				getCaptionFromTitleOrAlt:!1,
			});
		});
	}	
	
}
// -----------------------------------------------------
// ---------------   ESTIMATE WIDGET    ---------------
// -----------------------------------------------------
function cron_fn_estimateWidget(){
	"use strict";
	var est = jQuery('.cron_fn_widget_estimate');
	est.each(function(){
		var el = jQuery(this);
		var h1 = el.find('.helper1');
		var h2 = el.find('.helper2');
		var h3 = el.find('.helper3');
		var h4 = el.find('.helper4');
		var h5 = el.find('.helper5');
		var h6 = el.find('.helper6');
		var eW = el.outerWidth();
		var w1 = Math.floor((eW * 80) / 300);
		var w2 = eW-w1;
		var e1 = Math.floor((w1 * 55) / 80);
		h1.css({borderLeftWidth:w1+'px',borderTopWidth:e1+'px'});
		h2.css({borderRightWidth:w2+'px',borderTopWidth:e1+'px'});
		h3.css({borderLeftWidth:w1+'px',borderTopWidth:w1+'px'});
		h4.css({borderRightWidth:w2+'px',borderTopWidth:w1+'px'});
		h5.css({borderLeftWidth:w1+'px',borderTopWidth:w1+'px'});
		h6.css({borderRightWidth:w2+'px',borderTopWidth:w1+'px'});
	});
}
// -----------------------------------------------------
// --------------    AJAX (HARD WORK)    ---------------
// -----------------------------------------------------
var pageNumber = 1;

function cron_fn_projectFilter(){
	"use strict";
	var mainBtn = jQuery('.cron_fn_portfolio_category_filter > a');
	var filter	= jQuery('.portfolio_list ul.fn_filter');
	var btns 	= jQuery('.portfolio_list ul.fn_filter a');
	var spinner	= jQuery('.cron_fn_portfolio_category_filter span.spinner');
	var listIn	= jQuery('.cron_fn_portfolio_page .portfolio_list_in');
	
	if(jQuery().waitForImages){
		jQuery(window).load(function(){
			jQuery('.cron_fn_portfolio_page .portfolio_list_in').waitForImages(function() {
				setTimeout(function(){
					listIn.css({height:jQuery('.cron_fn_portfolio_page .portfolio_list_in').height()});
				},1500);
			});
		});
	}
	
	jQuery(window).on('click',function() {
		filter.removeClass('opened');
	});
	
	mainBtn.on('click',function(event){
		event.stopPropagation();
		if(filter.hasClass('opened')){
			filter.removeClass('opened');
		}else{
			filter.addClass('opened');
		}
		return false;
	});
	btns.on('click',function(){
		var element = jQuery(this);
		var ID 		= element.data('filter-value');
		var name 	= element.data('filter-name');
		listIn.addClass('active');
		spinner.addClass('active');
		btns.removeClass('active');
		element.addClass('active');
		doAjaxCall(ID, 1);
		mainBtn.html(name);
		filter.removeClass('opened');
		pageNumber = 1;
		return false;
	});
	mainBtn.html(jQuery('.portfolio_list ul.fn_filter a.active').html());
}

function cron_fn_ajaxPagination(){
	"use strict";
	
	jQuery('.cron_fn_ajax_pagination ul.ajax_pagination li a.next').on('click', function(){
		if(jQuery(this).hasClass('inactive')) {return false;}
		pageNumber++;
		var currentCat = jQuery('ul.fn_filter a.active').data('filter-value');
		if(currentCat == 'undefined'){currentCat = '';}
		doAjaxCall(currentCat, pageNumber);
		return false;
	});
	jQuery('.cron_fn_ajax_pagination ul.ajax_pagination li a.prev').on('click', function(){
		if(jQuery(this).hasClass('inactive')) {return false;}
		pageNumber--;
		var currentCat = jQuery('ul.fn_filter a.active').data('filter-value');
		if(currentCat == 'undefined'){currentCat = '';}
		doAjaxCall(currentCat, pageNumber);
		return false;
	});
}

// AJAX CALL
function doAjaxCall(currentCategory, page){
	"use strict";


	var requestData = {
		action: 'cron_fn_ajax_service_list',
		cron_fn_cat: currentCategory,
		cron_fn_page: page
	};
	jQuery.ajax({
		type: 'POST',
		url: fn_ajax_object.fn_ajax_url,
		cache: true,
		data: requestData,
		success: function(data, textStatus, XMLHttpRequest) {
			frenifyAjaxProcess(data);
		},
		error: function(MLHttpRequest, textStatus, errorThrown) {
			console.log('Error');
		}
	});	
}
function frenifyAjaxProcess(data){
	"use strict";
	console.log(data);
	var fnQueriedObj = jQuery.parseJSON(data); //get the data object
	var ul 		= jQuery('ul.cron_fn_portfolio_list');
	var spinner	= jQuery('.cron_fn_portfolio_category_filter span.spinner');
	ul.html(fnQueriedObj.cron_fn_data);
	
	//hide or show prev
	if ( true === fnQueriedObj.cron_fn_hide_prev ) {
		jQuery('.cron_fn_ajax_pagination ul li a.prev').addClass('inactive');
	} else {
		jQuery('.cron_fn_ajax_pagination ul li a.prev').removeClass('inactive');
	}

	//hide or show next
	if ( true === fnQueriedObj.cron_fn_hide_next ) {
		jQuery('.cron_fn_ajax_pagination ul li a.next').addClass('inactive');
	} else {
		jQuery('.cron_fn_ajax_pagination ul li a.next').removeClass('inactive');
	}
	
	portfolioListHeightRegular();
	spinner.removeClass('active');
	cron_fn_dataBgImg();
	cron_fn_imgToSvg();
}
function portfolioListHeightRegular(){
	"use strict";
	var listIn	= jQuery('.cron_fn_portfolio_page .portfolio_list_in');
	listIn.removeClass('active').css({height:'auto'});
}
// -----------------------------------------------------
// --------------    JUSTIFIED IMAGES    ---------------
// -----------------------------------------------------
function cron_fn_justified_images(){
	"use strict";
	var justified = jQuery(".cron_fn_justified_images");
	justified.each(function(){
		var element 	= jQuery(this);
		var justHeight	= element.attr('data-just-h');
		var justGutter	= element.attr('data-just-g');
		if(typeof(justHeight) !== 'undefined' && typeof(justGutter) !== 'undefined'){
			if(justHeight !== ''){justHeight = justHeight;}
			if(justGutter !== ''){justGutter = justGutter;}
		}else{justHeight = 300;justGutter = 10;}
		if(jQuery().justifiedGallery){
			element.justifiedGallery({
				rowHeight : justHeight,
				lastRow : 'nojustify',
				margins : justGutter,
				refreshTime: 500,
				refreshSensitivity: 0,
				maxRowHeight: null,
				border: 0,
				captions: false,
				randomize: false
			});
		}
	});
	var just 	= jQuery('.cron_fn_portfolio_justified');
	var justg	= just.attr('data-gutter');
	if(typeof(justg) !== 'undefined'){
		just.find('.j_list').css({paddingLeft:justg+'px',paddingRight:justg+'px'});
		just.css({marginTop: justg + 'px'});
	}
}
// -----------------------------------------------------
// ---------------   STICKY SIDEBAR    -----------------
// -----------------------------------------------------
function frenify_fn_sticky_sidebar(){
	"use strict";
	
	if(jQuery().theiaStickySidebar){
		jQuery('.frenify_fn_sticky_sidebar').theiaStickySidebar({
			containerSelector: '', // The sidebar's container element. If not specified, it defaults to the sidebar's parent.
			additionalMarginTop: 50,
			additionalMarginBottom: 0,
			updateSidebarHeight: true, // Updates the sidebar's height. Use this if the background isn't showing properly, for example.
			minWidth: 1200, // The sidebar returns to normal if its width is below this value. 
		});
	}
}
function cron_fn_allpages_height(){
	"use strict";
	
	var wrapperForH	 	= jQuery('.cron_fn_wfh'),
		footer		 	= jQuery('.cron_fn_footer'),
		mobMenu		 	= jQuery('.cron_fn_mobilemenu_wrap'),
		footerH			= 0,
		adminBarH		= 0,
		mobMenuH		= 0,
		H				= jQuery(window).height(),
		W				= jQuery(window).width(),
		body			= jQuery('body');
	
	if(body.hasClass('admin-bar')){
		adminBarH		= 32;
	}
	
	if(footer.length){
		footerH			= jQuery('.cron_fn_footer').outerHeight();
	}
	if(mobMenu.length){
		mobMenuH		= jQuery('.cron_fn_mobilemenu_wrap').outerHeight();
	}
	if(W<=1040){
		mobMenuH		= mobMenuH;
	}else{
		mobMenuH		= 0;
	}
	// FOR ALL PAGES
	wrapperForH.css({minHeight:(H-footerH-adminBarH-mobMenuH) + 'px'});
}
function cron_fn_isotope(){
	"use strict";
	var masonry = jQuery('.cron_fn_masonry');
	if(jQuery().isotope){
		masonry.each(function(){
			jQuery(this).isotope({
			  itemSelector: '.cron_fn_masonry_in',
			  masonry: {

			  }
			});
		});
	}
}
function cron_fn_postShapes(){
	"use strict";
	var post = jQuery('ul.cron_fn_postlist li > div');
	if(post.length){
		post.each(function(){
			var el 		= jQuery(this);
			var width	= Math.floor(el.width() - 100);
			var shape	= el.find('span.shape2');
			if(width > 0){
				if(shape.length){
					shape.css({borderLeftWidth:width + 'px'});
				}
			}
		});
	}
	var blogSingle 	= jQuery('.cron_fn_blog_single .fn-format-img');
	if(blogSingle.length){
		var width2		= Math.floor(blogSingle.width() - 100);
		var shape2 		= blogSingle.find('.shape2');
		if(width2 > 0){
			if(shape2.length){
				shape2.css({borderLeftWidth:width2 + 'px'});
			}
		}
	}
}