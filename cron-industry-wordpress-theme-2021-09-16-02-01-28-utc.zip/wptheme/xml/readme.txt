Hi.

Thank you for purchasing our theme.

Import below link into your Theme Options:

https://frenify.net/envato/frenify/wp/cron/2/wp-admin/admin-ajax.php?action=redux_download_options-redux_demo&secret=25dd4a6e0b628b955d20df037e8936f4

Best Regards